#!/bin/bash

git rm binding.gyp
git commit -m "bindings removed"
